import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLeads, Lead } from '@/contexts/LeadsContext';
import { useSession } from '@/contexts/SessionContext';
import { useAudioRecorder } from '@/hooks/useAudioRecorder';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { BackButton } from '@/components/ui/BackButton';
import { 
  Phone, 
  PhoneOff, 
  Mic, 
  Building2, 
  User, 
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react';

type CallResult = Lead['callResult'];

type CallState = 'idle' | 'calling' | 'completed';

export default function CallScreen() {
  const { leadId } = useParams<{ leadId: string }>();
  const navigate = useNavigate();
  const { getLeadById, completeLead, currentLead } = useLeads();
  const { incrementLeadsCompleted } = useSession();
  const { 
    isRecording, 
    audioLevel, 
    startRecording, 
    stopRecording, 
    uploadRecording,
    triggerTranscription 
  } = useAudioRecorder();
  
  const [callState, setCallState] = useState<CallState>('idle');
  const [callDuration, setCallDuration] = useState(0);
  const [answered, setAnswered] = useState<boolean | null>(null);
  const [result, setResult] = useState<CallResult | null>(null);
  const [notes, setNotes] = useState('');
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const lead = leadId ? getLeadById(leadId) : currentLead;

  useEffect(() => {
    if (!lead) {
      navigate('/caller/leads');
    }
  }, [lead, navigate]);

  const startCall = async () => {
    try {
      await startRecording();
      setCallState('calling');
      timerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Failed to start recording:', error);
      // Continue without recording if permission denied
      setCallState('calling');
      timerRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
  };

  const endCall = async () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    setIsUploading(true);
    
    try {
      const recordingData = await stopRecording();
      
      if (recordingData && lead) {
        // Upload recording to Supabase Storage (returns file path)
        const filePath = await uploadRecording(recordingData.blob, lead.id);
        if (filePath) {
          setRecordingUrl(filePath);
          
          // Update lead with recording path
          await supabase
            .from('leads')
            .update({ recording_url: filePath })
            .eq('id', lead.id);
        }
      }
    } catch (error) {
      console.error('Error processing recording:', error);
    } finally {
      setIsUploading(false);
      setCallState('completed');
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isCallValid = callDuration >= 4 && recordingUrl !== null;
  
  const canComplete = 
    callState === 'completed' &&
    answered !== null &&
    result !== null &&
    isCallValid;

  const handleComplete = async () => {
    if (!lead || !result) return;
    
    await completeLead(lead.id, result, callDuration, notes || undefined);
    incrementLeadsCompleted();
    
    // Trigger transcription in background
    if (recordingUrl) {
      triggerTranscription(recordingUrl, lead.id);
    }
    
    navigate('/caller/leads');
  };

  const getResultOptions = (): { value: CallResult; label: string; icon: React.ReactNode }[] => {
    if (answered === false) {
      return [
        { value: 'no_answer', label: 'Pas de réponse', icon: <PhoneOff className="w-4 h-4" /> }
      ];
    }
    return [
      { value: 'answered_not_interested', label: 'Pas intéressé', icon: <XCircle className="w-4 h-4" /> },
      { value: 'answered_interested', label: 'Intéressé', icon: <CheckCircle2 className="w-4 h-4" /> },
      { value: 'answered_closed', label: 'Fermé / Conclu', icon: <CheckCircle2 className="w-4 h-4" /> }
    ];
  };

  if (!lead) return null;

  return (
    <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8 max-w-2xl">
      {/* Lead Info */}
      <div className="glass rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6">
        <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl bg-primary/10 flex items-center justify-center">
            <Building2 className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-lg sm:text-xl font-bold text-foreground truncate">{lead.companyName}</h1>
            {lead.contactName && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <User className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="truncate">{lead.contactName}</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-base sm:text-lg font-mono text-foreground">
          <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground flex-shrink-0" />
          <span className="truncate">{lead.phone}</span>
        </div>
      </div>

      {/* Call Controls */}
      <div className="glass rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6">
        <div className="text-center">
          {/* Timer & Recording Indicator */}
          <div className="mb-4 sm:mb-6">
            <div className={`
              inline-flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full text-xl sm:text-2xl font-mono
              ${isRecording ? 'bg-destructive/10 text-destructive animate-pulse' : 'bg-muted text-muted-foreground'}
            `}>
              {isRecording && <Mic className="w-4 h-4 sm:w-5 sm:h-5" />}
              <Clock className="w-4 h-4 sm:w-5 sm:h-5" />
              {formatDuration(callDuration)}
            </div>
            
            {/* Audio Level Indicator */}
            {isRecording && (
              <div className="mt-3 sm:mt-4 flex items-center justify-center gap-0.5 sm:gap-1">
                {[...Array(10)].map((_, i) => (
                  <div
                    key={i}
                    className={`w-1.5 sm:w-2 rounded-full transition-all duration-75 ${
                      i < audioLevel * 10 ? 'bg-destructive' : 'bg-muted'
                    }`}
                    style={{ height: `${10 + i * 1.5}px` }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Call Buttons */}
          {callState === 'idle' && (
            <Button variant="call" size="xl" onClick={startCall} className="w-full">
              <Phone className="w-5 h-5" />
              Démarrer l'appel
            </Button>
          )}

          {callState === 'calling' && (
            <div className="space-y-3">
              <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4">
                <span className="inline-flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-destructive animate-pulse"></span>
                  Enregistrement en cours...
                </span>
              </p>
              <Button 
                variant="end" 
                size="xl" 
                onClick={endCall} 
                className="w-full"
                disabled={isUploading}
              >
                <PhoneOff className="w-5 h-5" />
                {isUploading ? 'Sauvegarde...' : 'Terminer l\'appel'}
              </Button>
            </div>
          )}

          {callState === 'completed' && !isCallValid && (
            <div className="flex flex-col items-center gap-2 text-destructive bg-destructive/10 rounded-lg p-3">
              <div className="flex items-center gap-2 text-sm">
                <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                <span>L'appel doit durer au moins 4 secondes</span>
              </div>
              {!recordingUrl && (
                <span className="text-xs sm:text-sm">et avoir un enregistrement valide</span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Completion Form */}
      {callState === 'completed' && isCallValid && (
        <div className="glass rounded-xl sm:rounded-2xl p-4 sm:p-6 animate-slide-up space-y-4 sm:space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-semibold text-foreground">Résultat de l'appel</h2>
            {recordingUrl && (
              <div className="flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                Enregistré
              </div>
            )}
          </div>

          {/* Did they answer? */}
          <div>
            <label className="text-sm font-medium text-foreground block mb-2 sm:mb-3">
              Le lead a-t-il répondu ?
            </label>
            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              <Button
                variant={answered === true ? 'default' : 'outline'}
                onClick={() => { setAnswered(true); setResult(null); }}
                className="h-11 sm:h-12"
              >
                <CheckCircle2 className="w-4 h-4" />
                Oui
              </Button>
              <Button
                variant={answered === false ? 'default' : 'outline'}
                onClick={() => { setAnswered(false); setResult('no_answer'); }}
                className="h-11 sm:h-12"
              >
                <XCircle className="w-4 h-4" />
                Non
              </Button>
            </div>
          </div>

          {/* Result */}
          {answered !== null && (
            <div className="animate-slide-up">
              <label className="text-sm font-medium text-foreground block mb-2 sm:mb-3">
                Résultat
              </label>
              <div className="grid grid-cols-1 gap-2">
                {getResultOptions().map(option => (
                  <Button
                    key={option.value}
                    variant={result === option.value ? 'default' : 'outline'}
                    onClick={() => setResult(option.value)}
                    className="h-11 sm:h-12 justify-start"
                  >
                    {option.icon}
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Duration (readonly) */}
          <div>
            <label className="text-sm font-medium text-foreground block mb-2">
              Durée de l'appel
            </label>
            <div className="flex items-center gap-2 bg-muted rounded-lg px-3 sm:px-4 py-2.5 sm:py-3">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="font-mono text-sm sm:text-base">{formatDuration(callDuration)}</span>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-sm font-medium text-foreground block mb-2">
              Notes (optionnel)
            </label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ajoutez des notes sur cet appel..."
              className="min-h-[80px] sm:min-h-[100px] text-base"
            />
          </div>

          {/* Complete Button */}
          <Button
            variant="success"
            size="lg"
            onClick={handleComplete}
            disabled={!canComplete}
            className="w-full h-12"
          >
            <CheckCircle2 className="w-5 h-5" />
            Compléter le lead
          </Button>
        </div>
      )}

      {/* Back Button */}
      {callState === 'idle' && (
        <div className="text-center mt-4 sm:mt-6">
          <BackButton to="/caller/leads" label="Retour à la liste" />
        </div>
      )}
    </div>
  );
}
