import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/BackButton';
import { Brain, Loader2, RefreshCw, TrendingUp, TrendingDown, Lightbulb, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';

export default function Insights() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [stats, setStats] = useState<{
    total_analyzed: number;
    interested_count: number;
    not_interested_count: number;
  } | null>(null);

  const analyzePatterns = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-patterns', {
        body: { caller_id: user.id }
      });

      if (error) {
        console.error('Error analyzing patterns:', error);
        toast.error('Erreur lors de l\'analyse');
        return;
      }

      if (data.error) {
        toast.error(data.error);
        return;
      }

      if (!data.analysis) {
        toast.info(data.message || 'Aucun transcript à analyser');
        return;
      }

      setAnalysis(data.analysis);
      setStats(data.stats);
      toast.success('Analyse terminée !');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Erreur lors de l\'analyse');
    } finally {
      setIsLoading(false);
    }
  };

  // Parse markdown sections for better display
  const renderAnalysis = (text: string) => {
    const sections = text.split(/(?=## )/);
    
    return sections.map((section, index) => {
      if (!section.trim()) return null;

      const lines = section.split('\n');
      const title = lines[0]?.replace('## ', '').trim();
      const content = lines.slice(1).join('\n').trim();

      let icon = <Lightbulb className="w-5 h-5" />;
      let bgClass = 'bg-muted/50';
      
      if (title?.includes('fonctionne bien') || title?.includes('🎯')) {
        icon = <TrendingUp className="w-5 h-5 text-success" />;
        bgClass = 'bg-success/10 border-success/20';
      } else if (title?.includes('amélioré') || title?.includes('⚠️')) {
        icon = <TrendingDown className="w-5 h-5 text-warning" />;
        bgClass = 'bg-warning/10 border-warning/20';
      } else if (title?.includes('Conseils') || title?.includes('💡')) {
        icon = <Lightbulb className="w-5 h-5 text-primary" />;
        bgClass = 'bg-primary/10 border-primary/20';
      } else if (title?.includes('Statistiques') || title?.includes('📊')) {
        icon = <BarChart3 className="w-5 h-5 text-info" />;
        bgClass = 'bg-info/10 border-info/20';
      }

      return (
        <div key={index} className={`rounded-xl p-5 border ${bgClass} mb-4`}>
          <div className="flex items-center gap-2 mb-3">
            {icon}
            <h3 className="font-semibold text-foreground">{title?.replace(/[🎯⚠️💡📊]/g, '').trim()}</h3>
          </div>
          <div className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">
            {content.split('\n').map((line, i) => {
              // Format list items
              if (line.trim().startsWith('-')) {
                return (
                  <p key={i} className="ml-4 mb-1.5">
                    • {line.replace(/^-\s*/, '')}
                  </p>
                );
              }
              if (line.trim()) {
                return <p key={i} className="mb-2">{line}</p>;
              }
              return null;
            })}
          </div>
        </div>
      );
    });
  };

  return (
    <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8 max-w-3xl">
      <div className="mb-3 sm:mb-4">
        <BackButton to="/caller" label="Retour à l'accueil" />
      </div>

      <div className="text-center mb-6 sm:mb-8">
        <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl bg-primary/10 mb-3 sm:mb-4">
          <Brain className="w-7 h-7 sm:w-8 sm:h-8 text-primary" />
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-foreground mb-1 sm:mb-2">
          Insights IA
        </h1>
        <p className="text-sm sm:text-base text-muted-foreground px-2">
          Analysez vos appels pour identifier ce qui fonctionne et améliorer vos performances
        </p>
      </div>

      {/* Stats Summary */}
      {stats && (
        <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-4 sm:mb-6">
          <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
            <p className="text-xl sm:text-2xl font-bold text-foreground">{stats.total_analyzed}</p>
            <p className="text-[10px] sm:text-xs text-muted-foreground">Appels analysés</p>
          </div>
          <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
            <p className="text-xl sm:text-2xl font-bold text-success">{stats.interested_count}</p>
            <p className="text-[10px] sm:text-xs text-muted-foreground">Intéressés</p>
          </div>
          <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
            <p className="text-xl sm:text-2xl font-bold text-warning">{stats.not_interested_count}</p>
            <p className="text-[10px] sm:text-xs text-muted-foreground">Pas intéressés</p>
          </div>
        </div>
      )}

      {/* Analysis Button */}
      <div className="flex justify-center mb-6 sm:mb-8">
        <Button 
          onClick={analyzePatterns} 
          disabled={isLoading}
          size="lg"
          className="gap-2 w-full sm:w-auto"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
              <span className="text-sm sm:text-base">Analyse en cours...</span>
            </>
          ) : analysis ? (
            <>
              <RefreshCw className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-sm sm:text-base">Relancer l'analyse</span>
            </>
          ) : (
            <>
              <Brain className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-sm sm:text-base">Analyser mes appels</span>
            </>
          )}
        </Button>
      </div>

      {/* Analysis Results */}
      {analysis && (
        <div className="space-y-2">
          {renderAnalysis(analysis)}
        </div>
      )}

      {/* Empty State */}
      {!analysis && !isLoading && (
        <div className="glass rounded-xl p-6 sm:p-8 text-center">
          <Brain className="w-10 h-10 sm:w-12 sm:h-12 text-muted-foreground/50 mx-auto mb-3 sm:mb-4" />
          <h3 className="text-base sm:text-lg font-medium text-foreground mb-2">
            Prêt à analyser vos performances
          </h3>
          <p className="text-xs sm:text-sm text-muted-foreground max-w-md mx-auto">
            L'IA va analyser les transcripts de vos appels pour identifier les patterns 
            qui mènent au succès et vous donner des conseils personnalisés.
          </p>
        </div>
      )}
    </div>
  );
}
