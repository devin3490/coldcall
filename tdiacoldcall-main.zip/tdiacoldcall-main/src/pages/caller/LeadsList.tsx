import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLeads } from '@/contexts/LeadsContext';
import { useSession } from '@/contexts/SessionContext';
import { LeadCard } from '@/components/caller/LeadCard';
import { Button } from '@/components/ui/button';
import { BackButton } from '@/components/ui/BackButton';
import { Square, Target, CheckCircle2, PhoneMissed } from 'lucide-react';

export default function LeadsList() {
  const navigate = useNavigate();
  const { visibleLeads, completedCount, totalLeads, callbackList, setCurrentLead } = useLeads();
  const { endSession, currentSession } = useSession();

  const handleCall = (leadId: string) => {
    const lead = visibleLeads.find(l => l.id === leadId);
    if (lead) {
      setCurrentLead(lead);
      navigate(`/caller/call/${leadId}`);
    }
  };

  const handleEndSession = () => {
    endSession();
    navigate('/caller');
  };

  return (
    <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8 max-w-3xl">
      {/* Back Button */}
      <div className="mb-3 sm:mb-4">
        <BackButton to="/caller" label="Retour à l'accueil" />
      </div>
      
      {/* Stats Bar */}
      <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-6 sm:mb-8">
        <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
          <Target className="w-4 h-4 sm:w-5 sm:h-5 text-primary mx-auto mb-1" />
          <p className="text-xl sm:text-2xl font-bold text-foreground">{totalLeads}</p>
          <p className="text-[10px] sm:text-xs text-muted-foreground">Total</p>
        </div>
        <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-success mx-auto mb-1" />
          <p className="text-xl sm:text-2xl font-bold text-success">{completedCount}</p>
          <p className="text-[10px] sm:text-xs text-muted-foreground">Complétés</p>
        </div>
        <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4 text-center">
          <PhoneMissed className="w-4 h-4 sm:w-5 sm:h-5 text-warning mx-auto mb-1" />
          <p className="text-xl sm:text-2xl font-bold text-warning">{callbackList.length}</p>
          <p className="text-[10px] sm:text-xs text-muted-foreground">À rappeler</p>
        </div>
      </div>

      {/* Visible Leads */}
      <div className="mb-4 sm:mb-6">
        <h2 className="text-base sm:text-lg font-semibold text-foreground mb-3 sm:mb-4">
          Vos prochains leads
        </h2>
        
        {visibleLeads.length > 0 ? (
          <div className="space-y-3 sm:space-y-4">
            {visibleLeads.map((lead, index) => (
              <LeadCard
                key={lead.id}
                lead={lead}
                isActive={index === 0}
                order={index + 1}
                onCall={() => handleCall(lead.id)}
              />
            ))}
          </div>
        ) : (
          <div className="glass rounded-xl p-6 sm:p-8 text-center">
            <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12 text-success mx-auto mb-3 sm:mb-4" />
            <h3 className="text-lg sm:text-xl font-semibold text-foreground mb-2">
              Tous les leads sont complétés !
            </h3>
            <p className="text-sm text-muted-foreground">
              Vous avez terminé tous vos leads assignés.
            </p>
          </div>
        )}
      </div>

      {/* Remaining Count */}
      {visibleLeads.length > 0 && (
        <p className="text-center text-xs sm:text-sm text-muted-foreground mb-6 sm:mb-8">
          {totalLeads - completedCount - visibleLeads.length} leads supplémentaires après ceux-ci
        </p>
      )}

      {/* End Session Button */}
      <div className="flex justify-center">
        <Button variant="end" size="lg" onClick={handleEndSession} className="w-full sm:w-auto">
          <Square className="w-4 h-4" />
          Terminer la session
        </Button>
      </div>
    </div>
  );
}
