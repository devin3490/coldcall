import { useSession } from '@/contexts/SessionContext';
import { useLeads } from '@/contexts/LeadsContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Play, Phone, Target, Clock, Square } from 'lucide-react';

export default function StartWork() {
  const { startSession, endSession, isSessionActive, sessionDuration } = useSession();
  const { totalLeads, completedCount, isLoading, refreshLeads } = useLeads();
  const navigate = useNavigate();

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = async () => {
    await refreshLeads();
    await startSession();
    navigate('/caller/leads');
  };

  const handleStop = async () => {
    await endSession();
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4">
      <div className="text-center w-full max-w-md">
        <div className="inline-flex items-center justify-center w-20 h-20 sm:w-24 sm:h-24 rounded-2xl sm:rounded-3xl bg-primary/10 mb-6 sm:mb-8">
          <Phone className="w-10 h-10 sm:w-12 sm:h-12 text-primary" />
        </div>
        
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2 sm:mb-3">
          {isSessionActive ? 'Session en cours' : 'Prêt à travailler ?'}
        </h1>
        <p className="text-sm sm:text-base text-muted-foreground mb-6 sm:mb-8 px-2">
          {isSessionActive 
            ? 'Votre session est active. Continuez vos appels ou arrêtez la session.'
            : 'Cliquez sur Démarrer quand vous êtes prêt à commencer votre session d\'appels.'}
        </p>

        <div className="flex flex-col gap-3 mb-8 sm:mb-12">
          {isSessionActive ? (
            <>
              <Button 
                variant="destructive" 
                size="xl" 
                onClick={handleStop}
                className="w-full sm:w-auto sm:mx-auto"
              >
                <Square className="w-5 h-5" />
                Arrêter la session
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                onClick={() => navigate('/caller/leads')}
                className="w-full sm:w-auto sm:mx-auto"
              >
                <Phone className="w-4 h-4" />
                Continuer les appels
              </Button>
            </>
          ) : (
            <Button 
              variant="start" 
              size="xl" 
              onClick={handleStart}
              disabled={isLoading}
              className="w-full sm:w-auto sm:mx-auto"
            >
              <Play className="w-5 h-5" />
              Démarrer la session
            </Button>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 sm:gap-4 text-center">
          <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4">
            <Target className="w-5 h-5 sm:w-6 sm:h-6 text-primary mx-auto mb-1 sm:mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-foreground">
              {isLoading ? '-' : totalLeads}
            </p>
            <p className="text-[10px] sm:text-xs text-muted-foreground">Leads assignés</p>
          </div>
          <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4">
            <Phone className="w-5 h-5 sm:w-6 sm:h-6 text-success mx-auto mb-1 sm:mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-foreground">
              {isLoading ? '-' : completedCount}
            </p>
            <p className="text-[10px] sm:text-xs text-muted-foreground">Complétés</p>
          </div>
          <div className="glass rounded-lg sm:rounded-xl p-3 sm:p-4">
            <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-warning mx-auto mb-1 sm:mb-2" />
            <p className="text-xl sm:text-2xl font-bold text-foreground">
              {isSessionActive ? formatTime(sessionDuration) : '--:--'}
            </p>
            <p className="text-[10px] sm:text-xs text-muted-foreground">Temps</p>
          </div>
        </div>

        {totalLeads === 0 && !isLoading && (
          <p className="mt-6 sm:mt-8 text-xs sm:text-sm text-muted-foreground px-4">
            Aucun lead ne vous est assigné pour le moment. Contactez votre administrateur.
          </p>
        )}
      </div>
    </div>
  );
}