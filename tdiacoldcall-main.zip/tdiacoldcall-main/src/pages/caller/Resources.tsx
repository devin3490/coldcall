import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useResources, Resource } from '@/hooks/useResources';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ResourceUploadDialog } from '@/components/resources/ResourceUploadDialog';
import { 
  FileText, 
  Video, 
  HelpCircle, 
  Download, 
  Trash2, 
  ExternalLink,
  Loader2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const categoryIcons = {
  scripts: FileText,
  videos: Video,
  faq: HelpCircle,
};

function ResourceCard({ 
  resource, 
  canManage, 
  onDelete 
}: { 
  resource: Resource; 
  canManage: boolean;
  onDelete: (id: string, fileUrl: string | null) => Promise<void>;
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const Icon = categoryIcons[resource.category];

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await onDelete(resource.id, resource.file_url);
      toast.success('Ressource supprimée');
    } catch (err) {
      toast.error('Erreur lors de la suppression');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Card className="glass overflow-hidden">
      <CardHeader className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Icon className="w-5 h-5 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <CardTitle className="text-base font-semibold">{resource.title}</CardTitle>
              {resource.description && (
                <p className="text-sm text-muted-foreground mt-1">{resource.description}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {resource.file_url && (
              <Button variant="outline" size="icon" asChild>
                <a href={resource.file_url} target="_blank" rel="noopener noreferrer">
                  {resource.category === 'videos' ? (
                    <ExternalLink className="w-4 h-4" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                </a>
              </Button>
            )}
            {resource.content && (
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setIsExpanded(!isExpanded)}
              >
                {isExpanded ? (
                  <ChevronUp className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </Button>
            )}
            {canManage && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                    {isDeleting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Supprimer cette ressource ?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Cette action est irréversible. La ressource sera définitivement supprimée.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Annuler</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Supprimer
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </div>
      </CardHeader>
      
      {resource.content && isExpanded && (
        <CardContent className="pt-0 pb-4 px-4 border-t border-border/50">
          <div className="mt-3 p-3 bg-secondary/30 rounded-lg">
            <p className="text-sm text-foreground whitespace-pre-wrap">{resource.content}</p>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export default function Resources() {
  const { profile } = useAuth();
  const { resources, isLoading, refetch, deleteResource } = useResources();
  
  const canManage = profile?.role === 'admin' || profile?.role === 'supervisor';

  const scripts = resources.filter(r => r.category === 'scripts');
  const videos = resources.filter(r => r.category === 'videos');
  const faqs = resources.filter(r => r.category === 'faq');

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] p-3 sm:p-4 md:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4 sm:mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground mb-0.5 sm:mb-1">Ressources</h1>
            <p className="text-sm text-muted-foreground">
              Outils et documents pour vous aider dans vos appels
            </p>
          </div>
          {canManage && (
            <ResourceUploadDialog onSuccess={refetch} />
          )}
        </div>

        <Tabs defaultValue="scripts" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-4 sm:mb-6 h-auto">
            <TabsTrigger value="scripts" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-1 sm:px-3">
              <FileText className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Scripts</span> ({scripts.length})
            </TabsTrigger>
            <TabsTrigger value="videos" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-1 sm:px-3">
              <Video className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Vidéos</span> ({videos.length})
            </TabsTrigger>
            <TabsTrigger value="faq" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-1 sm:px-3">
              <HelpCircle className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">FAQ</span> ({faqs.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scripts">
            {scripts.length === 0 ? (
              <Card className="glass">
                <CardContent className="py-12 text-center">
                  <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Aucun script disponible pour le moment.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {scripts.map(resource => (
                  <ResourceCard 
                    key={resource.id} 
                    resource={resource} 
                    canManage={canManage}
                    onDelete={deleteResource}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="videos">
            {videos.length === 0 ? (
              <Card className="glass">
                <CardContent className="py-12 text-center">
                  <Video className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Aucune vidéo disponible pour le moment.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {videos.map(resource => (
                  <ResourceCard 
                    key={resource.id} 
                    resource={resource} 
                    canManage={canManage}
                    onDelete={deleteResource}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="faq">
            {faqs.length === 0 ? (
              <Card className="glass">
                <CardContent className="py-12 text-center">
                  <HelpCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Aucune FAQ disponible pour le moment.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {faqs.map(resource => (
                  <ResourceCard 
                    key={resource.id} 
                    resource={resource} 
                    canManage={canManage}
                    onDelete={deleteResource}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
