import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Users, 
  Phone, 
  Clock, 
  FileText,
  Play,
  ChevronRight,
  CheckCircle2,
  XCircle,
  PhoneMissed,
  Calendar
} from 'lucide-react';

type CallResultFilter = 'all' | 'interested' | 'not_interested' | 'no_answer' | 'closed';

export default function SupervisorReview() {
  const [selectedCaller, setSelectedCaller] = useState<string | null>(null);
  const [filter, setFilter] = useState<CallResultFilter>('all');

  const callers = [
    { id: '1', name: 'John Caller', completedToday: 12, avgDuration: '2:15' },
    { id: '2', name: 'Marie Dupont', completedToday: 8, avgDuration: '3:02' },
    { id: '3', name: 'Pierre Martin', completedToday: 15, avgDuration: '1:45' },
  ];

  const calls = [
    { 
      id: '1', 
      company: 'TechStart SAS', 
      contact: 'Marie Dupont', 
      duration: '2:34',
      result: 'interested',
      time: '14:32',
      hasRecording: true,
      hasTranscript: true
    },
    { 
      id: '2', 
      company: 'Digital Solutions', 
      contact: 'Pierre Martin', 
      duration: '0:45',
      result: 'not_interested',
      time: '14:15',
      hasRecording: true,
      hasTranscript: true
    },
    { 
      id: '3', 
      company: 'InnovateTech', 
      contact: null, 
      duration: '0:12',
      result: 'no_answer',
      time: '14:02',
      hasRecording: true,
      hasTranscript: false
    },
  ];

  const getResultIcon = (result: string) => {
    switch (result) {
      case 'interested': return <CheckCircle2 className="w-4 h-4 text-success" />;
      case 'closed': return <CheckCircle2 className="w-4 h-4 text-primary" />;
      case 'not_interested': return <XCircle className="w-4 h-4 text-muted-foreground" />;
      case 'no_answer': return <PhoneMissed className="w-4 h-4 text-warning" />;
      default: return null;
    }
  };

  const getResultLabel = (result: string) => {
    switch (result) {
      case 'interested': return 'Intéressé';
      case 'closed': return 'Conclu';
      case 'not_interested': return 'Pas intéressé';
      case 'no_answer': return 'Pas de réponse';
      default: return result;
    }
  };

  return (
    <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8">
      <div className="mb-6 sm:mb-8">
        <h1 className="text-xl sm:text-2xl font-bold text-foreground">Contrôle Qualité</h1>
        <p className="text-sm sm:text-base text-muted-foreground">Écoutez et analysez les appels des callers</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Callers List */}
        <div className="lg:col-span-1">
          <div className="glass rounded-xl p-3 sm:p-4">
            <h2 className="text-xs sm:text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 sm:mb-4">
              Callers
            </h2>
            <div className="space-y-2">
              {callers.map(caller => (
                <button
                  key={caller.id}
                  onClick={() => setSelectedCaller(caller.id)}
                  className={`
                    w-full text-left p-2.5 sm:p-3 rounded-lg transition-all
                    ${selectedCaller === caller.id 
                      ? 'bg-primary/10 border border-primary/30' 
                      : 'hover:bg-secondary'
                    }
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-medium text-foreground">
                          {caller.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium text-foreground text-xs sm:text-sm truncate">{caller.name}</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground">
                          {caller.completedToday} appels aujourd'hui
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Calls List */}
        <div className="lg:col-span-3">
          {/* Filters */}
          <div className="flex items-center gap-2 mb-3 sm:mb-4 overflow-x-auto pb-2 -mx-1 px-1">
            {[
              { value: 'all', label: 'Tous' },
              { value: 'interested', label: 'Intéressés' },
              { value: 'closed', label: 'Conclus' },
              { value: 'not_interested', label: 'Pas intéressés' },
              { value: 'no_answer', label: 'Pas de réponse' },
            ].map(f => (
              <Button
                key={f.value}
                variant={filter === f.value ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter(f.value as CallResultFilter)}
                className="flex-shrink-0 text-xs sm:text-sm h-8 sm:h-9"
              >
                {f.label}
              </Button>
            ))}
          </div>

          {/* Calls */}
          <div className="space-y-2 sm:space-y-3">
            {calls.map(call => (
              <div key={call.id} className="glass rounded-xl p-3 sm:p-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div className="flex items-center gap-3 sm:gap-4">
                    <div className="flex flex-col items-center gap-1">
                      {getResultIcon(call.result)}
                      <span className="text-[10px] sm:text-xs text-muted-foreground">{call.time}</span>
                    </div>
                    
                    <div className="min-w-0">
                      <h3 className="font-medium text-foreground text-sm sm:text-base truncate">{call.company}</h3>
                      {call.contact && (
                        <p className="text-xs sm:text-sm text-muted-foreground truncate">{call.contact}</p>
                      )}
                      <div className="flex items-center gap-2 sm:gap-3 mt-1">
                        <span className="text-[10px] sm:text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {call.duration}
                        </span>
                        <span className={`
                          text-[10px] sm:text-xs px-1.5 sm:px-2 py-0.5 rounded-full
                          ${call.result === 'interested' ? 'bg-success/10 text-success' : ''}
                          ${call.result === 'closed' ? 'bg-primary/10 text-primary' : ''}
                          ${call.result === 'not_interested' ? 'bg-muted text-muted-foreground' : ''}
                          ${call.result === 'no_answer' ? 'bg-warning/10 text-warning' : ''}
                        `}>
                          {getResultLabel(call.result)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    {call.hasRecording && (
                      <Button variant="outline" size="sm" className="h-8 text-xs sm:text-sm">
                        <Play className="w-3 h-3 sm:w-4 sm:h-4" />
                        <span className="hidden sm:inline ml-1">Écouter</span>
                      </Button>
                    )}
                    {call.hasTranscript && (
                      <Button variant="ghost" size="sm" className="h-8 text-xs sm:text-sm">
                        <FileText className="w-3 h-3 sm:w-4 sm:h-4" />
                        <span className="hidden sm:inline ml-1">Transcript</span>
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {!selectedCaller && (
            <div className="glass rounded-xl p-8 sm:p-12 text-center">
              <Users className="w-10 h-10 sm:w-12 sm:h-12 text-muted-foreground mx-auto mb-3 sm:mb-4" />
              <h3 className="text-base sm:text-lg font-semibold text-foreground mb-2">
                Sélectionnez un caller
              </h3>
              <p className="text-sm text-muted-foreground">
                Choisissez un caller dans la liste pour voir ses appels
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
